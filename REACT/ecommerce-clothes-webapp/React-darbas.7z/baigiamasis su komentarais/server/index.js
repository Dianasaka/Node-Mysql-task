const express = require('express'); 
const app = express();
// dotenv naudojamas laikyti raktams, slaptažodžiams ir programos 
// veikimą keičiančius/nusakančius kintamuosius (pvz.: kintamasis nusakantis ar 
// programa veikia production, ar development rėžime). 

// Laikyti kode slaptažodžių, ar kitų saugumo duomenų, nepatartina, nes
// programos kurėjas gali lengvai pamiršti, kad kažkur kode yra duomenų bazės
// slaptažodis ir pasidalinti kodu per github. Galima nustatyti, kad .env faila git'as ignoruotu. 

// Be to daug lengviau rasti šiuos kintamuosius, kai jie vienoje vietoje, 
// kodas tvarkingesnis išlieka. 
require('dotenv').config(); 

// Importuoju routes failus. 
const dalyviaiRoutes = require("./routes/dalyviai.js");
const renginiaiRoutes = require("./routes/renginiai.js");

// Nurodau express'ui, kad naudosiu ejs. ejs yra templatų kalba (templating language). 
// Šis įrankis leidžia naudoti JavaScript'ą HTML failuose, taip palengvina programos kūrimą. 
// Taip pat leidžia padalinti HTML failus į kelis failus. Tarkim galima sukurti failą 
// kur aprašysiu <head> ir šį failą importuoti bet kuriame kitame ejs faile. Taip nereikės 
// kiekviename html faile aprašynėti <head> duomenų. 

// Pvz.: norėsiu vaizduoti dalyvių sąrašą savo HTML faile, bet dalyvių gali būti ir vienas, 
// ir du, ir šimtas. Todėl naudoju ejs ir iškart faile naudoju JS ciklą, kuris įterpia į failą
// nurodytus duomenis. Tą patį galima pasiekti rašant JavaScript'ą tradiciniu būdu, be 
// templatų kalbos, bet naudojant ejs susimažinu kodo kiekį, kurį turėčiau rašyti. 
app.set('view engine', 'ejs');

// Nurodau express'ui, kad ejs failų ieškotų /views folderyje. 
app.set('views', `${__dirname}/views`);

// Middleware
// Middleware'as - programos dalis, kuri kažkaip koreguoja užklausą, prieš jai pasiekiant
// endpoint'ą. 
// Kitaip tariant - endpoint'as yra atsakingas už užklausos ivykdymą/atsakymą, o
// middleware'as paruošia užklausą endpoint'ui. 
// Middleware'as gali būti įvairaus pobūdžio. Pvz.: autorizuoti vartotoja. Jeigu 
// vartotojas neprisijungęs - rodyti prisijungimo formą, kitu atveju rodyti duomenis. 

// express'ui nurodau, kur bus statiški(nekintantys failai) pvz.: html, css failai, nuotraukos
// Naudoju, nes yra logotipas. 
app.use(express.static(__dirname + '/public'));
// urlencoded padeda tvarkytis su formų duomenimis, kuriuos gauname su POST request'u/užklausa. 
// Panašus middleware'as yra express.json(), kurį naudojame kai tikimės gauti JSON duomenis. 
app.use(express.urlencoded());

// Routes
// express'ui nurodau, routes/kelius, per kuriuos pasiekti endpoint'us. 
// Pvz.: localhost:5000 naudos visus kelius, kurie nurodyti dalyviaiRoutes. 
// localhost:5000/renginiai naudos kelius, kurie nurodyti renginiaiRoutes. 
app.use('/', dalyviaiRoutes);
app.use('/renginiai', renginiaiRoutes);

// Nurodom, kad serveris lauks užklausų ateinančių per 5000 port'ą. 
app.listen(5000, () => console.log("Serveris veikia, klauso 5000 porto"));