// Čia apibūdinami keliai yra susije su dalyviais.
// Importuoju kontrolerius (endpoint'us)
const { gautiDalyvius } = require('../controllers/dalyviai/index.js');
const { registruotiDalyvi } = require('../controllers/dalyviai/registracija.js');
const { registruotiDalyviPost } = require('../controllers/dalyviai/registracijaPost.js');
const { istrintiDalyvi } = require('../controllers/dalyviai/istrinti.js');
const router = require('express').Router();

// localhost:5000 - grąžina html su dalyvių sąrašu. 
router.get('/', gautiDalyvius);

// localhost:5000/registracija - grąžina html su registracijos formą
router.get('/registracija', registruotiDalyvi);

// localhost:5000/registracija - naudoja POST vietoje GET. Šis endpoint'as
// suveiks kai vartotojas paspaus mygtuką registruoti formoje ir tada patalpins
// duomenis duomenų bazėje. 
router.post('/registracija', registruotiDalyviPost);

// localhost:5000 - Jeigu būtų pabaigtas endpoint'as, tai ištrintu dalyvį iš duomenų bazės. 
//router.delete('/istrinti', istrintiDalyvi);

module.exports = router;