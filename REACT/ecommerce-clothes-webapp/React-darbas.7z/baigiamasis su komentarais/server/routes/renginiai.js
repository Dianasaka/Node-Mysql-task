// Čia apibūdinami keliai yra susije su renginiais.
// Importuoju kontrolerius (endpoint'us)
const { gautiRenginius } = require('../controllers/renginiai/index.js');
const router = require('express').Router();

// localhost:5000/renginiai - grąžins html su renginiais
router.get('/', gautiRenginius);

module.exports = router;