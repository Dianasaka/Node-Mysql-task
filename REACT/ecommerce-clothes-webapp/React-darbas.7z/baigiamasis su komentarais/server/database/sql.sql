// SQL komando rasomos per MySQL Shell. 
// Prisijungiu prie duomenų bazės. 
mysql -u root -p
// Sukuriu 'baigiamasis' duomenų bazę. 
CREATE DATABASE baigiamasis;
// Nurodau, kad noriu dirbti su 'baigiamasis' DB. 
USE baigiamasis;

// mysql.js (Node.js biblioteka) negali prisijungti nesuvedus šitos eilutės
ALTER USER 'root'@'localhost' IDENTIFIED WITH mysql_native_password BY 'labas123';

// Renginių lentelė. Šitą lentelę reikia sukurti pirmą, nes dalyvių lentelė naudoja FOREIGN KEY, 
// su kuriuo susiejamos abi lentelės. 
CREATE TABLE renginiai(
renginio_id INT AUTO_INCREMENT, 
pavadinimas VARCHAR(100) NOT NULL, 
prasideda DATETIME NOT NULL, 
PRIMARY KEY(renginio_id));

// Trys eilutės (trys renginiai) įdedami į renginių lentelę. Nėra sukurtos formos ir endpointo,
// per kurį būtų galima kurti renginius. 
INSERT INTO renginiai (pavadinimas, prasideda) VALUES ('Koncertas', '2023-03-30 18:50:00');
INSERT INTO renginiai (pavadinimas, prasideda) VALUES ('Dazasvydzio turnyras', '2023-08-16 12:30:00');
INSERT INTO renginiai (pavadinimas, prasideda) VALUES ('Automobiliu paroda', '2024-01-12 14:00:00');

// Dalyvių lentelė. 
CREATE TABLE dalyviai(
dalyvio_id INT AUTO_INCREMENT,
vardas VARCHAR(100) NOT NULL,
pavarde VARCHAR(100) NOT NULL,
el_pastas VARCHAR(100) NOT NULL,
amzius INT NOT NULL,
gimimo_data DATE NOT NULL,
renginio_id int NOT NULL, 
FOREIGN KEY (renginio_id) REFERENCES renginiai(renginio_id),
PRIMARY KEY(dalyvio_id));

// Dalyvių lentelei eilutė. 
INSERT INTO dalyviai (vardas, pavarde, el_pastas, amzius, gimimo_data, renginio_id) VALUES ('Jonas', 'Jonaitis', 'jonas@gmail.com', '25', '1997-12-22', 3);
