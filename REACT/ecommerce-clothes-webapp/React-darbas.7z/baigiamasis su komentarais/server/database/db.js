// Šiame faile susijungiu su mysql duomenų baze ir eksportuoju query fukciją, 
// kuria naudosiu kitose programos vietose, kad gauti duomenis. 
// Naudoju mysql.js biblioteka
const mysql = require('mysql');

// Iš .env failo paimu host, user, password, duomenų bazės pavadinimą ir port'ą. 
const connection = mysql.createConnection({
  host: process.env.MYSQL_HOST,
  user: process.env.MYSQL_USERNAME,
  password: process.env.MYSQL_PASSWORD, 
  database: process.env.MYSQL_DATABASE,
  port: process.env.MYSQL_PORT
});

//Sukuriamas susijungimas su duomenų baze. 
connection.connect(function(err) {
  console.log(process.env.MYSQL_HOST);
  // Jeigu nepavyksta, spausdinu klaidą, kurią gavau iš mysql.js
  if (err) {
    console.error('error connecting: ' + err.stack);
    return;
  }

  console.log('connected as id ' + connection.threadId);
});

// Eksportuoju funkciją, su kuria siųsiu užklausas į duomenų bazę. 
// Funkcijos parametrai: 
// sql: SQL užklausos string'as.  

// values: masyvas, talpinami kintamieji, kuriuos noriu įrašyti į SQL užklausą. 
// Šis masyvas egzistuoja tam, kad prieš iklijuojant reikšmes į SQL string'ą
// jos būtų escape'intos (kad būtų išvengta SQL injekcijos atakų). 

// callback: čia suteikiama funkcija, kurią mysql.js iškvies kai gaus atsakymą iš duomenų bazės. 
// Toje funkcijoje bus arba spausdinama klaida, jeigu nepavyko, arba toliau atliekami veiksmai su gautais duomenimis. 
module.exports = { query: (sql, values, callback) => connection.query(sql, values, callback) }