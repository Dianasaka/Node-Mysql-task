// Importuoju duomenų bazės funkcijas
const db = require("../../database/db");

// Gražina html su renginių sąrašu. 
exports.gautiRenginius = (req, res) => {
    // SQL užklausa.
    db.query("SELECT * FROM renginiai;", [], function(error, results){
        if(error){
            // Jeigu gaunu error'ą iš duomenų bazės, tai spausdinu jį konsolėje. 
            // Siunčiu atgal 500 (internal server error) statusą ir JSON
            // su žinute, kad nepavyko. 
           console.log(error);
           res.status(500).json({
               "msg": "Ivyko klaida"
           });
        } else {
            // Šis kodas įvyks jeigu pavyko gauti duomenis iš duomenų bazės. 
            // Tada siunčiu html ir duomenų objektą, kuriame yra renginiai.
            res.status(200).render("renginiai.ejs", { duomenys: results });
    };
 } 
 )};
