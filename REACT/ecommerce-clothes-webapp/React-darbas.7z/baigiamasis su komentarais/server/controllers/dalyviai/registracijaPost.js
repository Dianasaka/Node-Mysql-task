// Importuoju duomenų bazės funkcijas
const db = require('../../database/db.js');

// Talpina dalyvį į duomenų bazę. 
exports.registruotiDalyviPost = (req, res) => {
    // SQL užklausa į duomenų bazę. 
    db.query("INSERT INTO dalyviai " + 
    "(vardas, pavarde, el_pastas, amzius, gimimo_data, renginio_id) " + 
    "VALUES (?, ?, ?, ?, ?, ?);", 
    [req.body.vardas, req.body.pavarde, req.body.el_pastas, req.body.amzius, req.body.gimimo_data, req.body.renginio_id], 
    function (error, results) {
        if (error) {
            // Jeigu gaunu error'ą iš duomenų bazės, tai spausdinu jį konsolėje. 
            // Siunčiu atgal 500 (internal server error) statusą ir JSON
            // su žinute, kad nepavyko. 
            console.log(error);
            res.status(500).json({
                "msg": "Ivyko klaida"
            });
        } else {
            // Šis kodas įvyks jeigu pavyko gauti duomenis iš duomenų bazės. 
            // Jeigu pavyko, grįžtu į dalyvių sąrašą. 
            res.redirect("/");
        }
    });
}