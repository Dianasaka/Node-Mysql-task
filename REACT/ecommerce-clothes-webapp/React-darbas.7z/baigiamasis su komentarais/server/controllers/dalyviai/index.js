// Importuoju duomenų bazės funkcijas
const db = require("../../database/db");

// Gražina html su dalyvių sąrašu. 
exports.gautiDalyvius = (req, res) => {
    // SQL užklausa. Naudoju JOIN, kad būtų iš renginių lentelės paimtas pavadinimas, 
    // kokiame dalyvis renginyje dalyvauja. 
    db.query("SELECT * FROM dalyviai INNER JOIN renginiai ON dalyviai.renginio_id=renginiai.renginio_id;", [], function (error, results) {
        if (error) {
            // Jeigu gaunu error'ą iš duomenų bazės, tai spausdinu jį konsolėje. 
            // Siunčiu atgal 500 (internal server error) statusą ir JSON
            // su žinute, kad nepavyko. 
            console.log(error);
            res.status(500).json({
                "msg": "Ivyko klaida"
            });
        } else {
            // Šis kodas įvyks jeigu pavyko gauti duomenis iš duomenų bazės. 
            // Tada siunčiu html ir duomenų objektą, kuriame yra dalyviai. 
            res.status(200).render("dalyviai.ejs", { duomenys: results });
        }
    });
}