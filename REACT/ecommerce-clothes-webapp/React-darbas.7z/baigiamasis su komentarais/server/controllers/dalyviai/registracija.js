// Importuoju duomenų bazės funkcijas
const db = require('../../database/db.js');

// Gražina html su registracijos forma
exports.registruotiDalyvi = (req, res) => {
    // SQL užklausa. Registracijos formoje galima pasirinkti į kokį renginį dalyvis
    // eina, todėl reikia gauti renginių sąrašą iš duomenų bazės. 
    db.query("SELECT * FROM renginiai;", [], function (error, results) {
        if (error) {
            // Jeigu gaunu error'ą iš duomenų bazės, tai spausdinu jį konsolėje. 
            // Siunčiu atgal 500 (internal server error) statusą ir JSON
            // su žinute, kad nepavyko. 
            console.log(error);
            res.status(500).json({
                "msg": "Ivyko klaida"
            });
        } else {
            // Šis kodas įvyks jeigu pavyko gauti duomenis iš duomenų bazės. 
            // Tada siunčiu html su forma ir duomenų objektą, kuriame yra renginiai. 
            res.status(200).render("registracija.ejs", { results: results });
        }
    });
    
}